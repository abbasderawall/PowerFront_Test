<h1>ABBAS's TEST For PorwerFront</h1>

ASP.NET Core MVC (.NET 5), ASP.NET Core Razor Pages, Dependency Injection, Entity Framework Core, SQL Server 2019, CRUD Operations.

This <em><strong>ongoing application (TEST)</strong></em> uses MVC design pattern. So far, it performs Mentioned Operations in PDF file, utilising Entity Framework Core.

1. Open the Project in Visual Stodio 
2. Change the connection string with you loacal DB Server
3. Database back file, .mdf file and Script is also attached, so you can restore DB or attach .mdf file or also you can run query.
4. Run the project.

Thanks & Regards
Muhammad Abbas
