﻿using Chat.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chat.Data.Repository.IRepository
{

    public interface IConversation : IRepository<Conversation>
    {
    }
  
}
